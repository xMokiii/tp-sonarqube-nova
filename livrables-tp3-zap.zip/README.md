# TP3 - DAST avec OWASP ZAP

Ouvrir tp3/README.md puis tp3/compte-rendu.md.
Le workflow GitHub Actions est dans .github/workflows/dast.yml.
Les rapports et preuves du workflow sont dans tp3/preuves/.
