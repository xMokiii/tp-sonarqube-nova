<?php phpinfo() ?>
